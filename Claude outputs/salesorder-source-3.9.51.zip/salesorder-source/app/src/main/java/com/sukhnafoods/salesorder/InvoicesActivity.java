package com.sukhnafoods.salesorder;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.sukhnafoods.salesorder.databinding.ActivityInvoicesBinding;
import com.sukhnafoods.salesorder.model.DetailFsi;
import com.sukhnafoods.salesorder.model.PastInvoice;
import com.sukhnafoods.salesorder.net.ApiClient;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Past sales invoices — one entry per posted factory sales invoice (Party ·
 *  Invoice No · date · N items) with a View button, plus a Party filter, a
 *  search box, and a "Sync from PACT" button. Auto-refreshed 4 AM IST server-side. */
public class InvoicesActivity extends AppCompatActivity {

    private ActivityInvoicesBinding b;
    private final InvoiceEntryAdapter adapter = new InvoiceEntryAdapter(this::showInvoice);
    private boolean pulling = false;
    private String channel = "B2B";
    private boolean nb() { return "NB".equals(channel); }

    private List<String> columns = new ArrayList<>();
    private final List<PastInvoice> all = new ArrayList<>();     // full grouped set
    private String selectedParty = "";
    private String query = "";
    private List<String> partyValues = new ArrayList<>();
    private String lastUpdated = "", dateLabel = "";

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        b = ActivityInvoicesBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        channel = getIntent().getStringExtra("CHANNEL");
        if (channel == null || channel.isEmpty()) channel = "B2B";
        if (nb()) setTitle("View past sales invoice (NB)");
        b.rvInvoices.setLayoutManager(new LinearLayoutManager(this));
        b.rvInvoices.setAdapter(adapter);

        b.btnSyncInv.setOnClickListener(v -> pullFresh());

        b.etInvSearch.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int c, int d) {}
            @Override public void onTextChanged(CharSequence s, int a, int c, int d) { query = s.toString(); applyFilter(); }
            @Override public void afterTextChanged(android.text.Editable s) {}
        });

        b.spParty.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) {
                selectedParty = (pos <= 0 || pos > partyValues.size()) ? "" : partyValues.get(pos - 1);
                applyFilter();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> p) {}
        });

        showSnapshot();     // show the saved snapshot instantly (opening stays fast)
    }

    private int dp(float v) { return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics())); }
    private void setStatus(String m) { if (b != null) b.tvInvStatus.setText(m); }

    private void showSnapshot() {
        ApiClient.Cb<com.sukhnafoods.salesorder.model.DetailFsi> onData = (d, err) -> {
            onSnapshot(d, err);
        };
        if (nb()) ApiClient.getNbInvoices(onData); else ApiClient.getDetailFsi(onData);
    }
    private void onSnapshot(com.sukhnafoods.salesorder.model.DetailFsi d, String err) {
        {
            if (d == null) { if (!pulling) setStatus("Couldn't load invoices" + (err != null ? ": " + err : "")); return; }
            render(d);
        }
    }

    /** Tap "Sync from PACT": pull all of today's invoices (from 4 AM to now). */
    private void pullFresh() {
        if (pulling) return;
        pulling = true;
        b.btnSyncInv.setEnabled(false);
        setStatus("Syncing invoices from PACT… (about 1–2 min).");
        ApiClient.SyncProgress prog = stage -> setStatus("Syncing invoices from PACT — " + stage + "…");
        ApiClient.Cb<String> done = (okMsg, err) -> {
            pulling = false;
            b.btnSyncInv.setEnabled(true);
            if (okMsg == null) { setStatus("Showing last saved — sync failed: " + (err != null ? err : "unknown")); showSnapshot(); return; }
            showSnapshot();
        };
        if (nb()) ApiClient.runOutletReqSync(prog, done); else ApiClient.runDetailFsiSync(prog, done);
    }

    private int col(String... names) {
        for (int pass = 0; pass < 2; pass++)
            for (int i = 0; i < columns.size(); i++) {
                String h = columns.get(i) == null ? "" : columns.get(i).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
                for (String n : names) if (pass == 0 ? h.equals(n) : h.contains(n)) return i;
            }
        return -1;
    }

    private void render(DetailFsi d) {
        columns = d.columns;
        lastUpdated = d.syncedAt == null ? "" : d.syncedAt.replace("T", " ");
        if (lastUpdated.length() > 16) lastUpdated = lastUpdated.substring(0, 16);
        dateLabel = (d.dateFrom == null || d.dateFrom.isEmpty()) ? ""
                : (d.dateFrom.equals(d.dateTo) ? d.dateFrom : d.dateFrom + " → " + d.dateTo);

        int iDoc = col("docno"), iParty = col("accountname", "account", "party"), iDate = col("docdate", "date");
        int iItems = col("items", "itemcount");   // summary list carries a per-invoice item count
        Map<String, PastInvoice> map = new LinkedHashMap<>();
        for (List<String> row : d.rows) {
            String key = (iDoc >= 0 && iDoc < row.size() ? row.get(iDoc) : "").trim();
            if (key.isEmpty()) key = "(no invoice no)";
            PastInvoice inv = map.get(key);
            if (inv == null) {
                inv = new PastInvoice();
                inv.invoiceNo = key;
                inv.party = iParty >= 0 && iParty < row.size() ? row.get(iParty) : "";
                inv.docDate = iDate >= 0 && iDate < row.size() ? row.get(iDate) : "";
                if (iItems >= 0 && iItems < row.size()) { try { inv.count = Integer.parseInt(row.get(iItems).trim()); } catch (Exception ignore) {} }
                map.put(key, inv);
            }
            inv.lines.add(row);
        }
        all.clear();
        all.addAll(map.values());
        all.sort((a, c) -> {
            String da = a.docDate == null ? "" : a.docDate, dc = c.docDate == null ? "" : c.docDate;
            int byDate = dc.compareTo(da);   // newest invoice date first
            if (byDate != 0) return byDate;
            return Integer.compare(numSuffix(c.invoiceNo), numSuffix(a.invoiceNo));
        });

        adapter.setSyncedLabel(istTimeLabel(d.syncedAt));
        populatePartyDropdown();
        applyFilter();
    }

    /** "synced HH:MM" (IST) from a UTC ISO timestamp, or "" if unparseable. */
    private String istTimeLabel(String iso) {
        if (iso == null || iso.length() < 19) return "";
        try {
            SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            in.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date dt = in.parse(iso.substring(0, 19));
            SimpleDateFormat out = new SimpleDateFormat("HH:mm", Locale.US);
            out.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
            return "synced " + out.format(dt);
        } catch (Exception e) { return ""; }
    }

    private void populatePartyDropdown() {
        TreeMap<String, Integer> counts = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        for (PastInvoice inv : all) {
            String p = inv.party == null ? "" : inv.party.trim();
            if (p.isEmpty()) continue;
            counts.merge(p, 1, Integer::sum);
        }
        partyValues = new ArrayList<>(counts.keySet());
        List<String> display = new ArrayList<>();
        display.add("All parties · " + all.size() + " invoices");
        for (String p : partyValues) display.add(p + "  (" + counts.get(p) + ")");
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, display);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        b.spParty.setAdapter(a);
        int idx = 0;
        if (!selectedParty.isEmpty()) { int i = partyValues.indexOf(selectedParty); if (i >= 0) idx = i + 1; else selectedParty = ""; }
        b.spParty.setSelection(idx);
    }

    private void applyFilter() {
        String q = query.trim().toLowerCase(Locale.ROOT);
        List<PastInvoice> out = new ArrayList<>();
        for (PastInvoice inv : all) {
            if (!selectedParty.isEmpty() && !(inv.party != null && inv.party.equalsIgnoreCase(selectedParty))) continue;
            if (!q.isEmpty()) {
                String no = inv.invoiceNo == null ? "" : inv.invoiceNo.toLowerCase(Locale.ROOT);
                String pa = inv.party == null ? "" : inv.party.toLowerCase(Locale.ROOT);
                if (!no.contains(q) && !pa.contains(q)) continue;
            }
            out.add(inv);
        }
        adapter.setItems(out);

        StringBuilder st = new StringBuilder();
        if (all.isEmpty()) { st.append(pulling ? "Syncing…" : "No invoices for this day yet. Tap “Sync from PACT”."); }
        else {
            st.append(out.size() == all.size() ? (all.size() + (all.size() == 1 ? " invoice" : " invoices"))
                    : ("Showing " + out.size() + " of " + all.size() + " invoices"));
            if (!dateLabel.isEmpty()) st.append("  ·  ").append(dateLabel);
            if (!lastUpdated.isEmpty()) st.append("  ·  updated ").append(lastUpdated);
        }
        if (pulling) st.append("  ·  refreshing…");
        setStatus(st.toString());
    }

    private static int numSuffix(String s) {
        if (s == null) return -1;
        Matcher m = Pattern.compile("(\\d+)\\s*$").matcher(s);
        return m.find() ? Integer.parseInt(m.group(1)) : -1;
    }

    /** Detail view: that invoice's product-line table. */
    /** Tap View → fetch this invoice's product lines on demand, then show them. */
    private void showInvoice(PastInvoice inv) {
        setStatus("Loading " + (inv.invoiceNo == null ? "invoice" : inv.invoiceNo) + "\u2026");
        ApiClient.getInvoiceLines(nb(), inv.invoiceNo, (det, err) -> {
            applyFilter();   // restore the status line
            if (det == null || det.rows == null || det.rows.isEmpty()) {
                toast("Couldn't load this invoice's items" + (err != null ? ": " + err : "") + ".");
                return;
            }
            renderInvoiceDialog(inv, det.columns, det.rows);
        });
    }

    /** Column lookup over a fetched detail column list (same matching as col()). */
    private static int colIn(List<String> cols, String... names) {
        for (int pass = 0; pass < 2; pass++)
            for (int i = 0; i < cols.size(); i++) {
                String h = cols.get(i) == null ? "" : cols.get(i).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
                for (String n : names) if (pass == 0 ? h.equals(n) : h.contains(n)) return i;
            }
        return -1;
    }

    private void toast(String m) { android.widget.Toast.makeText(this, m, android.widget.Toast.LENGTH_LONG).show(); }

    /** Detail table for one invoice, built from its fetched columns + line rows. */
    private void renderInvoiceDialog(PastInvoice inv, List<String> cols, List<List<String>> lines) {
        String[] heads; float[] widths; int[] idx;
        String nbOmr = "";
        int varReqIdx = -1, varOutIdx = -1;
        final InvoicePrinter.Doc[] pdoc = { null };   // set for NB so a "Print / PDF" button can appear
        if (nb()) {
            int iName = colIn(cols, "productname", "product"), iReqNo = colIn(cols, "outletreqno", "reqno"),
                iReq = colIn(cols, "reqqty"), iOut = colIn(cols, "outletqty"), iUnit = colIn(cols, "units", "unit");
            java.util.LinkedHashSet<String> omrs = new java.util.LinkedHashSet<>();
            if (iReqNo >= 0) for (List<String> l : lines) { if (iReqNo < l.size()) { String v = l.get(iReqNo); if (v != null && !v.trim().isEmpty()) omrs.add(v.trim()); } }
            nbOmr = android.text.TextUtils.join(", ", omrs);
            // Build the PACT-format "Stock Outward to Outlet" document for printing.
            {
                InvoicePrinter.Doc doc = new InvoicePrinter.Doc();
                doc.orderNo = inv.invoiceNo == null ? "" : inv.invoiceNo;
                doc.orderDate = inv.docDate == null ? "" : inv.docDate;
                doc.omr = nbOmr;
                doc.outlet = inv.party == null ? "" : inv.party;
                int iIssue = colIn(cols, "outletissuetype", "issuetype"), iLoc = colIn(cols, "location"),
                    iNarr = colIn(cols, "narration"), iLocTr = colIn(cols, "locationtransfer");
                doc.issueType = firstVal(lines, iIssue);
                doc.narration = firstVal(lines, iNarr);
                String loc = firstVal(lines, iLoc); if (!loc.isEmpty()) doc.location = loc;
                String lt = firstVal(lines, iLocTr); if (!lt.isEmpty()) doc.outlet = lt;
                java.util.List<InvoicePrinter.Line> pls = new java.util.ArrayList<>();
                double tr = 0, to = 0, tp = 0;
                for (List<String> l : lines) {
                    InvoicePrinter.Line pl = new InvoicePrinter.Line();
                    pl.name = cellAt(l, iName); pl.units = cellAt(l, iUnit);
                    double rq = num(iReq, l), oq = num(iOut, l);
                    pl.req = fmt3(rq); pl.out = fmt3(oq); pl.pend = fmt3(rq - oq);
                    tr += rq; to += oq; tp += (rq - oq);
                    pls.add(pl);
                }
                doc.lines = pls; doc.totReq = fmt3(tr); doc.totOut = fmt3(to); doc.totPend = fmt3(tp);
                pdoc[0] = doc;
            }
            heads = new String[]{ "S.No", "Product Name", "Units", "Ordered", "Dispatched", "Variance" };
            widths = new float[]{ 40, 150, 54, 74, 90, 78 };
            idx = new int[]{ -1, iName, iUnit, iReq, iOut, -2 };
            varReqIdx = iReq; varOutIdx = iOut;
        } else {
            int iName = colIn(cols, "productname", "product"), iHsn = colIn(cols, "gsthsnsaccode", "hsn", "sac"),
                iWh = colIn(cols, "warehouse"), iLvl = colIn(cols, "salesunitlevel", "unitlevel"),
                iQty = colIn(cols, "qty", "quantity"), iBatch = colIn(cols, "batchno", "batch"), iVal = colIn(cols, "value");
            heads = new String[]{ "S.No", "Product Name", "GST HSN", "Warehouse", "Level", "Qty", "Batch No", "Value" };
            widths = new float[]{ 48, 200, 96, 130, 60, 70, 130, 90 };
            idx = new int[]{ -1, iName, iHsn, iWh, iLvl, iQty, iBatch, iVal };
        }
        TableLayout table = new TableLayout(this);
        table.setPadding(dp(4), dp(4), dp(4), dp(4));
        TableRow head = new TableRow(this);
        head.setBackgroundColor(0xFF1565C0);
        for (int i = 0; i < heads.length; i++) head.addView(cell(heads[i], widths[i], true, Color.WHITE));
        table.addView(head);
        int n = 0;
        for (List<String> line : lines) {
            n++;
            TableRow tr = new TableRow(this);
            tr.setBackgroundColor((n % 2 == 0) ? 0xFFF2F6FB : 0xFFFFFFFF);
            for (int c = 0; c < heads.length; c++) {
                String v;
                if (c == 0) v = String.valueOf(n);
                else if (idx[c] == -2) v = variance(varReqIdx, varOutIdx, line);
                else v = (idx[c] >= 0 && idx[c] < line.size() ? line.get(idx[c]) : "");
                tr.addView(cell(v, widths[c], false, 0xFF222222));
            }
            table.addView(tr);
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.addView(table);
        // Header line (party · Order OMR · date) ABOVE the table, so a long OMR
        // wraps and stays fully visible instead of being cut off in the title.
        android.widget.LinearLayout colw = new android.widget.LinearLayout(this);
        colw.setOrientation(android.widget.LinearLayout.VERTICAL);
        StringBuilder hb = new StringBuilder();
        if (inv.party != null && !inv.party.isEmpty()) hb.append(inv.party);
        if (nb() && nbOmr != null && !nbOmr.isEmpty()) hb.append(hb.length() > 0 ? "\n" : "").append("Order: ").append(nbOmr);
        if (inv.docDate != null && !inv.docDate.isEmpty()) hb.append(hb.length() > 0 ? "\n" : "").append(inv.docDate);
        if (hb.length() > 0) {
            TextView hdr = new TextView(this);
            hdr.setText(hb.toString());
            hdr.setPadding(dp(14), dp(10), dp(14), dp(6));
            hdr.setTextColor(0xFF333333);
            hdr.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
            colw.addView(hdr);
        }
        colw.addView(hs);
        ScrollView sv = new ScrollView(this);
        sv.addView(colw);
        String title = (inv.invoiceNo == null ? "Invoice" : inv.invoiceNo);
        android.app.AlertDialog.Builder db = new android.app.AlertDialog.Builder(this).setTitle(title).setView(sv).setPositiveButton("Close", null);
        if (pdoc[0] != null) db.setNeutralButton("Print / PDF", (dd, ww) -> InvoicePrinter.print(this, pdoc[0]));
        db.show();
    }

    private static String variance(int iReq, int iOut, List<String> line) {
        double d = num(iReq, line) - num(iOut, line);
        if (d == Math.rint(d)) return String.valueOf((long) d);
        return String.valueOf(Math.round(d * 1000.0) / 1000.0);
    }
    private static double num(int i, List<String> line) {
        if (i < 0 || i >= line.size()) return 0;
        String s = line.get(i);
        if (s == null) return 0;
        s = s.replaceAll("[^0-9.\\-]", "");
        if (s.isEmpty() || s.equals("-") || s.equals(".")) return 0;
        try { return Double.parseDouble(s); } catch (Exception e) { return 0; }
    }

    private static String cellAt(List<String> l, int i) { return (i >= 0 && i < l.size() && l.get(i) != null) ? l.get(i) : ""; }
    private static String firstVal(List<List<String>> lines, int i) {
        if (i < 0) return "";
        for (List<String> l : lines) { String v = cellAt(l, i); if (v != null && !v.trim().isEmpty()) return v.trim(); }
        return "";
    }
    private static String fmt3(double d) { return String.format(Locale.US, "%.3f", d); }

    private TextView cell(String text, float widthDp, boolean bold, int color) {
        TextView tv = new TextView(this);
        tv.setText(text == null ? "" : text);
        tv.setWidth(dp(widthDp));
        tv.setPadding(dp(6), dp(5), dp(6), dp(5));
        tv.setTextColor(color);
        tv.setGravity(Gravity.START);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }
}
