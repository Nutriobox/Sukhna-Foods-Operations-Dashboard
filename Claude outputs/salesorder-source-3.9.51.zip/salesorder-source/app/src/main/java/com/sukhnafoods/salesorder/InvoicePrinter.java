package com.sukhnafoods.salesorder;

import android.content.Context;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.List;

/**
 * Builds a "Stock Outward to Outlet" document in PACT's exact layout and hands it
 * to Android's print framework (print to any paired/networked printer, or "Save as
 * PDF"). The Sukhna logo lives in app assets (sukhna_logo.png).
 */
public class InvoicePrinter {

    /** One product line for the printed table. */
    public static class Line {
        public String name = "", units = "", req = "", out = "", pend = "";
    }

    /** Everything the document header + table needs. */
    public static class Doc {
        public String orderNo = "", orderDate = "", omr = "";
        public String issueType = "", location = "Factory", outlet = "", narration = "";
        public String crateNo = "", toteNo = "";
        public List<Line> lines;
        public String totReq = "", totOut = "", totPend = "";
    }

    // Keep a strong reference to the WebView while the async print job runs.
    private static WebView sHolder;

    public static void print(Context ctx, Doc d) {
        final String html = buildHtml(d);
        final WebView wv = new WebView(ctx);
        wv.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                try {
                    PrintManager pm = (PrintManager) ctx.getSystemService(Context.PRINT_SERVICE);
                    String job = "StockOutward_" + safe(d.orderNo);
                    PrintAttributes attrs = new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .build();
                    pm.print(job, view.createPrintDocumentAdapter(job), attrs);
                } catch (Exception e) {
                    android.widget.Toast.makeText(ctx, "Print failed: " + e.getMessage(), android.widget.Toast.LENGTH_LONG).show();
                }
                sHolder = null;
            }
        });
        sHolder = wv;
        wv.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
    }

    private static String safe(String s) { return s == null ? "" : s.replaceAll("[^A-Za-z0-9]", "_"); }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private static String buildHtml(Doc d) {
        StringBuilder rows = new StringBuilder();
        int n = 0;
        if (d.lines != null) for (Line l : d.lines) {
            n++;
            rows.append("<tr><td class='center'>").append(n).append("</td><td>").append(esc(l.name))
                .append("</td><td>").append(esc(l.units)).append("</td><td class='num'>").append(esc(l.req))
                .append("</td><td class='num'>").append(esc(l.out)).append("</td><td class='num'>").append(esc(l.pend))
                .append("</td></tr>");
        }
        return "<!doctype html><html><head><meta charset='utf-8'><style>"
            + "@page{size:A4;margin:8mm;} *{box-sizing:border-box;} body{font-family:Arial,Helvetica,sans-serif;color:#000;font-size:11px;margin:0;}"
            + ".wrap{border:1px solid #000;} .hd{display:flex;align-items:flex-start;padding:6px 8px;border-bottom:1px solid #000;position:relative;}"
            + ".logo{width:150px;flex:0 0 150px;} .logo img{width:150px;height:auto;}"
            + ".co{flex:1;text-align:center;} .co .name{font-weight:800;font-size:17px;} .co .line{font-size:9.5px;}"
            + ".orig{position:absolute;right:8px;top:6px;font-size:10px;}"
            + ".title{text-align:center;font-weight:800;font-size:14px;padding:4px;border-bottom:1px solid #000;}"
            + "table{border-collapse:collapse;width:100%;} .info td{border:1px solid #000;padding:2px 5px;vertical-align:top;}"
            + ".info .k{font-weight:700;width:150px;} .info .c{width:10px;text-align:center;}"
            + ".grid th{background:#4f81bd;color:#fff;border:1px solid #000;padding:3px 5px;font-size:11px;}"
            + ".grid td{border:1px solid #000;padding:2px 5px;} .num{text-align:right;} .center{text-align:center;}"
            + ".tot td{border:1px solid #000;padding:3px 5px;font-weight:800;}"
            + "</style></head><body><div class='wrap'>"
            + "<div class='hd'><div class='logo'><img src='sukhna_logo.png'></div>"
            + "<div class='co'><div class='name'>Allsure Services Pvt. Ltd.</div>"
            + "<div class='line'>Plot A-181, Sector 63, Gautam Buddha Nagar, Noida -201301, Uttar Pradesh</div>"
            + "<div class='line'>Ph No:9555958959, Email Id: purchase@sukhnafoods.com, Web Site: www.sukhnafoods.com</div>"
            + "<div class='line'>GST No: 09AANCA9064A1ZL</div></div><div class='orig'>ORIGINAL</div></div>"
            + "<div class='title'>STOCK OUTWARD TO OUTLET</div>"
            + "<table class='info'>"
            + "<tr><td class='k'>Order No.</td><td class='c'>:</td><td>" + esc(d.orderNo) + "</td>"
            + "<td class='k'>Outlet Issue Type</td><td class='c'>:</td><td>" + esc(d.issueType) + "</td></tr>"
            + "<tr><td class='k'>Order Date</td><td class='c'>:</td><td>" + esc(d.orderDate) + "</td>"
            + "<td class='k'>Location</td><td class='c'>:</td><td>" + esc(d.location) + "</td></tr>"
            + "<tr><td class='k'>Perforated Big Crate No</td><td class='c'>:</td><td>" + esc(d.crateNo) + "</td>"
            + "<td class='k'>Location Transfer</td><td class='c'>:</td><td>" + esc(d.outlet) + "</td></tr>"
            + "<tr><td class='k'>60L Tote Box no</td><td class='c'>:</td><td>" + esc(d.toteNo) + "</td>"
            + "<td class='k' rowspan='2'>Narration</td><td class='c' rowspan='2'>:</td><td rowspan='2'>" + esc(d.narration) + "</td></tr>"
            + "<tr><td class='k'>Outlet ReqNo</td><td class='c'>:</td><td>" + esc(d.omr) + "</td></tr>"
            + "</table>"
            + "<table class='grid'><thead><tr><th style='width:36px'>SNO</th><th>Product Name</th><th style='width:64px'>Units</th>"
            + "<th style='width:66px'>ReqQty</th><th style='width:74px'>Outlet Qty</th><th style='width:74px'>PEND QTY</th></tr></thead>"
            + "<tbody>" + rows + "</tbody>"
            + "<tfoot><tr class='tot'><td colspan='3'>REPORT TOTAL</td><td class='num'>" + esc(d.totReq) + "</td>"
            + "<td class='num'>" + esc(d.totOut) + "</td><td class='num'>" + esc(d.totPend) + "</td></tr></tfoot>"
            + "</table></div></body></html>";
    }
}
