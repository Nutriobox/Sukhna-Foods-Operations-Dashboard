package com.sukhnafoods.salesorder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.sukhnafoods.salesorder.model.SalesOrder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;

/** Rows of pending sales orders: Vendor · SO number, with View + Start-to-scan.
 *  Filtered to a single vendor chosen from a dropdown (empty = all). */
public class SoAdapter extends RecyclerView.Adapter<SoAdapter.VH> {

    public interface Listener { void onView(SalesOrder o); void onScan(SalesOrder o); void onReopen(SalesOrder o); }

    private final List<SalesOrder> all = new ArrayList<>();   // full set
    private final List<SalesOrder> items = new ArrayList<>(); // filtered view
    private String vendorFilter = "";                          // "" = all vendors
    private String query = "";                                 // free-text search (order no / vendor)
    private final Listener listener;
    public SoAdapter(Listener l) { this.listener = l; }

    public void setOrders(List<SalesOrder> list) {
        all.clear(); all.addAll(list);
        // Newest order first: sort by the SO number's numeric suffix (then id), descending.
        Collections.sort(all, (a, b) -> {
            int sa = soSuffix(a.soNumber), sb = soSuffix(b.soNumber);
            if (sa != sb) return Integer.compare(sb, sa);
            return Long.compare(b.id, a.id);
        });
        apply();
    }

    private static int soSuffix(String so) {
        if (so == null) return -1;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+)\\s*$").matcher(so);
        return m.find() ? Integer.parseInt(m.group(1)) : -1;
    }
    public void setVendorFilter(String vendor) { vendorFilter = vendor == null ? "" : vendor.trim(); apply(); }

    public void setQuery(String q) { query = q == null ? "" : q.trim().toLowerCase(Locale.ROOT); apply(); }
    public int totalCount() { return all.size(); }
    public int visibleCount() { return items.size(); }

    /** Distinct vendor names, sorted A-Z (for the dropdown). */
    public List<String> distinctVendors() {
        TreeSet<String> set = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for (SalesOrder o : all) if (o.vendor != null && !o.vendor.isEmpty()) set.add(o.vendor);
        return new ArrayList<>(set);
    }

    /** Vendor name -> number of orders, sorted A-Z (for the dropdown labels). */
    public java.util.LinkedHashMap<String, Integer> vendorCounts() {
        java.util.TreeMap<String, Integer> t = new java.util.TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        for (SalesOrder o : all) {
            if (o.vendor == null || o.vendor.isEmpty()) continue;
            Integer c = t.get(o.vendor);
            t.put(o.vendor, c == null ? 1 : c + 1);
        }
        return new java.util.LinkedHashMap<>(t);
    }

    private void apply() {
        items.clear();
        for (SalesOrder o : all) {
            if (!vendorFilter.isEmpty() && !(o.vendor != null && o.vendor.equalsIgnoreCase(vendorFilter))) continue;
            if (!query.isEmpty()) {
                String so = safe(o.soNumber).toLowerCase(Locale.ROOT);
                String vn = safe(o.vendor).toLowerCase(Locale.ROOT);
                if (!so.contains(query) && !vn.contains(query)) continue;
            }
            items.add(o);
        }
        // Newest order first: by the SO number's numeric suffix (then id), descending.
        Collections.sort(items, (a, b) -> {
            int sa = soSuffix(a.soNumber), sb = soSuffix(b.soNumber);
            if (sa != sb) return Integer.compare(sb, sa);
            return Long.compare(b.id, a.id);
        });
        notifyDataSetChanged();
    }
    private static String safe(String s) { return s == null ? "" : s; }
    // Zero-pad the trailing number in the SO code so /9 sorts before /10.
    private static String soKey(String so) {
        if (so == null) return "";
        int i = so.length(); while (i > 0 && Character.isDigit(so.charAt(i - 1))) i--;
        String tail = so.substring(i);
        if (tail.isEmpty()) return so;
        while (tail.length() < 8) tail = "0" + tail;
        return so.substring(0, i) + tail;
    }

    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.row_so, p, false));
    }
    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        SalesOrder o = items.get(pos);
        h.vendor.setText(o.vendor);
        boolean hasDate = o.soDate != null && !o.soDate.isEmpty() && !o.soDate.equalsIgnoreCase("null");
        String date = hasDate ? " · " + o.soDate : "";
        // Fully dispatched in PACT (nothing left to dispatch) - shown, but marked completed.
        boolean serverDone = "completed".equalsIgnoreCase(o.status) || "done".equalsIgnoreCase(o.status);
        String st = serverDone ? " · COMPLETED" : "";
        h.so.setText(o.soNumber + date + " · " + o.itemCount + " item" + (o.itemCount == 1 ? "" : "s") + st);
        h.view.setOnClickListener(v -> listener.onView(o));

        // Completed = LOCKED. A sales order fully scanned here, or already dispatched
        // in PACT, cannot be reopened or rescanned (guards against double-dispatch).
        boolean localDone = ScanDraftStore.isCompleted(h.itemView.getContext(), o.soNumber);
        if (localDone || serverDone) {
            h.scan.setText("Completed");
            h.scan.setEnabled(false);
            h.scan.setOnClickListener(null);
        } else {
            h.scan.setText("Start to scan");
            h.scan.setEnabled(true);
            h.scan.setOnClickListener(v -> listener.onScan(o));
        }
    }
    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView vendor, so; final MaterialButton view, scan;
        VH(View v) { super(v); vendor = v.findViewById(R.id.tvVendor); so = v.findViewById(R.id.tvSo);
            view = v.findViewById(R.id.btnViewSo); scan = v.findViewById(R.id.btnScanSo); }
    }
}
