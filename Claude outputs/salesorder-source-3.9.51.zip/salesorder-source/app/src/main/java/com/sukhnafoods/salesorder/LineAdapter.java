package com.sukhnafoods.salesorder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * The dispatch table for one sales order, laid out like PACT's sales-order line
 * grid. One row per ordered product: Product code / name and GST HSN are auto-
 * fetched, S.O qty / Pending qty / Scanned qty share the line's UOM, and the
 * remaining columns mirror PACT (warehouse, rates, tax, batch, dates, ref).
 */
public class LineAdapter extends RecyclerView.Adapter<LineAdapter.VH> {

    /** One sales-order line as shown in the table. */
    public static class Row {
        public String code = "", name = "", hsn = "", uom = "";
        public double soQty, pendingQty, scannedQty;
        // remainQty = pending still LEFT to scan (required - scanned), shown in the
        // Pending column so it counts down live as items are scanned. pendingQty
        // keeps the original requirement (used for the row colour / validation).
        public double remainQty;
        // Per-batch display: each scanned batch is its own row. `head` is the
        // first row of a product (shows name/code + Pending/S.O qty); batch
        // sub-rows repeat only the batch columns. `productScanned` is the
        // product's total (across batches) used to colour the head row.
        public boolean head = true;
        public String numLabel = "";
        public double productScanned = 0;

        // PACT line columns (blank when the source data doesn't carry them yet)
        public String warehouse = "", salesUnitLevel = "", units = "", salesUnits = "";
        public String unitPrice = "", salesRate = "", gstTaxType = "", value = "";
        public String discPer = "", discAmt = "", taxableAmount = "", tax = "";
        public String sgst = "", cgst = "", igst = "";
        public String sgstAmount = "", cgstAmount = "", igstAmount = "";
        public String remarks = "", batchNo = "", mfgDate = "", expDate = "", refNo = "";

        // Delete control: the product code + batch this row represents, and whether
        // a delete (✕) button should show for it (only when this batch has scans).
        public String delCode = "";
        public boolean canDelete = false;
    }

    /** Tapped the ✕ on a scanned batch row. */
    public interface OnDeleteBatch { void onDelete(Row r); }
    private OnDeleteBatch onDelete;
    public void setOnDeleteBatch(OnDeleteBatch l) { this.onDelete = l; }

    private final List<Row> rows = new ArrayList<>();

    public void setRows(List<Row> newRows) {
        rows.clear();
        if (newRows != null) rows.addAll(newRows);
        notifyDataSetChanged();
    }

    public int size() { return rows.size(); }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.row_line, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Row r = rows.get(position);
        // The order's quantities are in the sales unit (packs/cartons) that PACT
        // does not expose in this report, so they carry NO unit label. The stock
        // unit (Gms) belongs to the batch quantities only — printing it here made
        // 72 packs read as "72 Gms".

        String su = (r.uom == null || r.uom.isEmpty()) ? "unit" : r.uom;
        h.tvNum.setText(r.numLabel == null ? "" : r.numLabel);
        // Product name/code and Pending/S.O qty appear only on the product's
        // first (head) row; batch sub-rows leave those blank.
        if (r.head) {
            h.tvCode.setText(orDash(r.code));
            h.tvName.setText(orDash(r.name));
            h.tvSoQty.setText(fmt(r.soQty) + " " + su);
            h.tvPend.setText(fmt(r.remainQty) + " " + su);
        } else {
            h.tvCode.setText("");
            h.tvName.setText("");
            h.tvSoQty.setText("");
            h.tvPend.setText("");
        }
        // Scanned qty is per-batch on every row.
        h.tvScan.setText(fmt(r.scannedQty) + " " + su);

        h.tvWh.setText(orDash(r.warehouse));
        h.tvBatch.setText(orDash(r.batchNo));
        h.tvMfg.setText(orDash(r.mfgDate));
        h.tvExp.setText(orDash(r.expDate));
        h.tvRefNo.setText(orDash(r.refNo));

        // Delete (✕) button: shown only on rows that carry a scanned batch.
        if (h.tvDel != null) {
            if (r.canDelete) {
                h.tvDel.setText("✕");
                h.tvDel.setVisibility(View.VISIBLE);
                h.tvDel.setOnClickListener(v -> { if (onDelete != null) onDelete.onDelete(r); });
            } else {
                h.tvDel.setText("");
                h.tvDel.setVisibility(View.INVISIBLE);
                h.tvDel.setOnClickListener(null);
            }
        }

        // Colour the head row by the PRODUCT total: green once pending is met,
        // red if exceeded. Batch sub-rows stay neutral.
        int colour = 0xFF0F172A;
        if (r.head) {
            if (r.productScanned > r.pendingQty + 1e-9) colour = 0xFFDC2626;
            else if (r.productScanned > 0 && r.productScanned >= r.pendingQty - 1e-9) colour = 0xFF15803D;
        }
        h.tvScan.setTextColor(colour);
    }

    @Override public int getItemCount() { return rows.size(); }

    static String orDash(String s) { return (s == null || s.isEmpty()) ? "—" : s; }

    static String fmt(double d) {
        if (d == Math.floor(d) && !Double.isInfinite(d)) return String.valueOf((long) d);
        return String.valueOf(d);
    }

    static class VH extends RecyclerView.ViewHolder {
        final TextView tvNum, tvName, tvCode, tvScan, tvPend, tvSoQty, tvWh, tvBatch, tvMfg, tvExp, tvRefNo, tvDel;
        VH(View v) {
            super(v);
            tvNum = v.findViewById(R.id.tvNum);     tvName = v.findViewById(R.id.tvName);
            tvCode = v.findViewById(R.id.tvCode);   tvScan = v.findViewById(R.id.tvScan);
            tvPend = v.findViewById(R.id.tvPend);   tvSoQty = v.findViewById(R.id.tvSoQty);
            tvWh = v.findViewById(R.id.tvWh);       tvBatch = v.findViewById(R.id.tvBatch);
            tvMfg = v.findViewById(R.id.tvMfg);     tvExp = v.findViewById(R.id.tvExp);
            tvRefNo = v.findViewById(R.id.tvRefNo); tvDel = v.findViewById(R.id.tvDel);
        }
    }
}
