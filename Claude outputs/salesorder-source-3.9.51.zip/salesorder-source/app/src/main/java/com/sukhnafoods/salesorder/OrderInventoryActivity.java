package com.sukhnafoods.salesorder;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.sukhnafoods.salesorder.databinding.ActivityOrderInventoryBinding;
import com.sukhnafoods.salesorder.model.Batch;
import com.sukhnafoods.salesorder.model.OrderLine;
import com.sukhnafoods.salesorder.model.ProductMaster;
import com.sukhnafoods.salesorder.model.ProductStock;
import com.sukhnafoods.salesorder.model.SalesOrderItem;
import com.sukhnafoods.salesorder.net.ApiClient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** "Start to scan" landing for one sales order. Stage 1: sync inventory from PACT.
 *  Stage 2: view the stock for just this order's items. Then: scan the order.
 *  In VIEW_ONLY mode it is a read-only look at the order's items + live stock:
 *  no scan button, nothing can be dispatched. */
public class OrderInventoryActivity extends AppCompatActivity {

    private ActivityOrderInventoryBinding b;
    private final SoBatchAdapter adapter = new SoBatchAdapter();
    private final Handler h = new Handler(Looper.getMainLooper());
    private AlertDialog progress;
    private TextView progressText;

    private long id;
    private String so, vendor, lastSynced = null;
    private String channel = "B2B";   // "NB" = NutrioBox outlet dispatch (Stock Outward)
    private boolean viewOnly = false; // read-only: show items + live stock, no scanning
    private final List<SalesOrderItem> items = new ArrayList<>();   // this order's lines

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        b = ActivityOrderInventoryBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        b.rvInv.setLayoutManager(new LinearLayoutManager(this));
        b.rvInv.setAdapter(adapter);

        id = getIntent().getLongExtra("ID", 0);
        so = getIntent().getStringExtra("SO_NUMBER");
        vendor = getIntent().getStringExtra("VENDOR");
        channel = getIntent().getStringExtra("CHANNEL");
        viewOnly = getIntent().getBooleanExtra("VIEW_ONLY", false);
        if (channel == null || channel.isEmpty()) channel = "B2B";
        b.tvHead.setText((vendor == null ? "" : vendor) + "\n" + (so == null ? "" : so));

        applyCompletedState();
        b.btnSync.setOnClickListener(v -> syncInventory());
        b.btnScan.setOnClickListener(v -> startActivity(new Intent(this, MainActivity.class)
                .putExtra("ID", id).putExtra("SO_NUMBER", so).putExtra("VENDOR", vendor)
                .putExtra("CHANNEL", channel)));
        if (viewOnly) { b.btnScan.setVisibility(View.GONE); b.btnScan.setOnClickListener(null); }

        // Learn which products are in this order (with retry), and show them right
        // away - the live stock/batch detail fills in after an inventory sync.
        loadOrder(0);
        ApiClient.getOrderStock(stockKey(), (inv, err) -> { if (inv != null) lastSynced = inv.syncedAt; });
        ApiClient.getProductMaster((m, err) -> {});   // packaging levels for the UOM conversion
    }

    /** Show the scan button unless we're in read-only view mode. */
    private void showScanButton() {
        b.btnScan.setVisibility(viewOnly ? View.GONE : View.VISIBLE);
    }

    /** Load the order's line items, retrying a few times so a momentary network
     *  blip doesn't leave the screen blank. Shows the items as soon as they arrive. */
    private void loadOrder(int tries) {
        ApiClient.Cb<com.sukhnafoods.salesorder.model.SalesOrder> onOrder = (order, err) -> {
            if (order == null) {
                if (tries < 4) { b.tvStatus.setText("Loading the order's items…"); h.postDelayed(() -> loadOrder(tries + 1), 1500); return; }
                b.tvStatus.setText("Couldn't load the order" + (err != null ? ": " + err : "") + " - check the connection and reopen.");
                return;
            }
            items.clear();
            items.addAll(order.items);
            b.tvHead.setText((vendor == null ? "" : vendor) + "\n" + (so == null ? "" : so) + " · " + items.size() + " items");
            renderItemsOnly();     // show the order's items immediately
            viewInventory();       // then enrich with live stock / batches
        };
        if (nb()) ApiClient.getOutletReqBySo(so, onOrder); else ApiClient.getSalesOrderBySo(so, onOrder);
    }

    private boolean nb() { return "NB".equals(channel); }
    /** Stock lookup key: NutrioBox pulls per-OMR stock, B2B pulls per-SO stock. */
    private String stockKey() { return nb() ? "omr:" + so : so; }

    /** Draw the order's items straight away (name / S.O qty / Pending qty), before
     *  any inventory sync, so the items are ALWAYS visible. */
    private void renderItemsOnly() {
        if (items.isEmpty()) { b.tvStatus.setText("This order has no items."); return; }
        List<SoBatchAdapter.Row> rows = new ArrayList<>();
        for (SalesOrderItem it : items) {
            String code = (it.code == null ? "" : it.code);
            SoBatchAdapter.Row r = new SoBatchAdapter.Row();
            r.name = it.name; r.soQty = it.ordered; r.pendingQty = it.qty;
            r.code = code; r.scannedQty = 0; r.idealWarehouse = idealFor(code, it.name);
            r.warehouse = ""; r.batch = "Tap Sync for stock"; r.batchQty = 0;
            r.uom = (it.unit != null ? it.unit : ""); r.stockUnit = "";
            r.batchPacks = 0d; r.packSize = UomConvert.scale(code, it.name);
            r.salesUnit = UomConvert.salesUnit(code, it.name);
            r.baseUnit = UomConvert.baseUnit(code, it.name);
            rows.add(r);
        }
        adapter.setRows(rows);
        b.tableWrap.setVisibility(View.VISIBLE);
        showScanButton();
        b.tvStatus.setText(items.size() + " order items · tap “Sync inventory from PACT” for live stock");
    }

    private void syncInventory() {
        showProgress("Syncing inventory from PACT… waiting for the run to finish (about 2 min).");
        ApiClient.runSync(
                stage -> { if (progressText != null) progressText.setText("Syncing inventory from PACT — " + stage + "…\n(about 2 min, please wait)"); },
                (okMsg, err) -> {
                    dismissProgress();
                    if (err != null) { toast("Sync failed: " + err); viewInventory(); return; }
                    toast("Inventory synced from PACT.");
                    viewInventory();
                });
    }

    private void pollSync(String before, int tries) {
        h.postDelayed(() -> ApiClient.getInventory((inv, err) -> {
            if (inv != null) lastSynced = inv.syncedAt;
            boolean changed = inv != null && inv.syncedAt != null && !inv.syncedAt.equals(before) && inv.batches > 0;
            if (changed) {
                dismissProgress();
                viewInventory();          // straight to the fresh stock table
                toast("Inventory synced from PACT.");
            } else if (tries < 30) pollSync(before, tries + 1);
            else {
                dismissProgress();
                b.tvStatus.setText("Sync is taking longer than usual - showing the stock we have.");
                viewInventory();
            }
        }), 2500);
    }

    /** Builds the order's stock table: Product name · S.O qty · Pending qty ·
     *  Batch no. · Qty vs batch, every quantity in the same UOM per line. */
    private void viewInventory() {
        b.tvStatus.setText("Loading this order's stock…");
        ApiClient.getOrderStock(stockKey(), (inv, err) -> {
            if (inv == null) { b.tvStatus.setText(items.size() + " order items · live stock unavailable - tap “Sync inventory from PACT”."); return; }
            if (items.isEmpty()) { return; }
            List<SoBatchAdapter.Row> rows = new ArrayList<>();
            int found = 0, batches = 0;
            // Scanned-so-far per product, from the on-device scan draft for this order.
            Map<String, Double> scannedByCode = new HashMap<>();
            Map<String, Double> scannedByName = new HashMap<>();
            ScanDraftStore.Draft draft = ScanDraftStore.load(this, so);
            if (draft != null) for (OrderLine l : draft.lines) {
                if (l.productCode != null && !l.productCode.isEmpty())
                    scannedByCode.merge(l.productCode.toUpperCase(Locale.ROOT), l.quantity, Double::sum);
                String nn = norm(l.productName);
                if (!nn.isEmpty()) scannedByName.merge(nn, l.quantity, Double::sum);
            }
            for (SalesOrderItem it : items) {
                String want = norm(it.name);
                ProductStock exact = null, loose = null;
                String exactCode = "", looseCode = "";
                for (Map.Entry<String, ProductStock> e : inv.byCode.entrySet()) {
                    String nm = norm(e.getValue().name);
                    if (nm.equals(want)) { exact = e.getValue(); exactCode = e.getKey(); break; }
                    if (loose == null && want.length() >= 5 && (nm.contains(want) || want.contains(nm))) {
                        loose = e.getValue(); looseCode = e.getKey();
                    }
                }
                ProductStock st = exact != null ? exact : loose;
                // the product code drives the master lookup (names are ambiguous)
                final String code = (exact != null) ? exactCode : looseCode;
                String uom = (it.unit != null && !it.unit.isEmpty()) ? it.unit : "";
                double scanned = scannedByCode.containsKey(code.toUpperCase(Locale.ROOT))
                        ? scannedByCode.get(code.toUpperCase(Locale.ROOT))
                        : scannedByName.getOrDefault(norm(it.name), 0d);
                String ideal = idealFor(code, it.name);

                if (st == null || st.batches == null || st.batches.isEmpty()) {
                    SoBatchAdapter.Row r = new SoBatchAdapter.Row();
                    r.name = it.name; r.soQty = it.ordered; r.pendingQty = it.qty;
                    r.code = code; r.scannedQty = scanned; r.idealWarehouse = ideal;
                    r.batch = "No stock"; r.batchQty = 0; r.uom = uom;
                    r.batchPacks = 0d; r.stockUnit = ""; r.packSize = UomConvert.scale(code, it.name);
                    r.salesUnit = UomConvert.salesUnit(code, it.name);
                    r.baseUnit = UomConvert.baseUnit(code, it.name);
                    rows.add(r);
                    continue;
                }
                found++;
                for (Batch bt : st.batches) {              // already FEFO-ordered
                    SoBatchAdapter.Row r = new SoBatchAdapter.Row();
                    r.name = it.name; r.soQty = it.ordered; r.pendingQty = it.qty;
                    r.code = code; r.scannedQty = scanned; r.idealWarehouse = ideal; r.warehouse = bt.warehouse;
                    r.batch = bt.batchNumber; r.batchQty = bt.available;
                    r.stockUnit = bt.unit;
                    r.batchPacks = UomConvert.toSalesUnits(bt.available, code, it.name);
                    r.packSize = UomConvert.scale(code, it.name);
                    r.salesUnit = UomConvert.salesUnit(code, it.name);
                    r.baseUnit = UomConvert.baseUnit(code, it.name);
                    r.uom = uom.isEmpty() ? bt.unit : uom;   // one UOM for all three quantities
                    rows.add(r);
                    batches++;
                }
            }
            adapter.setRows(rows);
            b.tableWrap.setVisibility(View.VISIBLE);
            showScanButton();
            b.tvStatus.setText(found + " of " + items.size() + " order items in stock · " + batches + " batches");
            // Auto-keep stock fresh: if the snapshot is stale, kick a background PACT
            // sync and silently re-pull this order's stock - no manual Sync tap needed.
            if (ApiClient.autoSyncIfStale(inv.syncedAt) || batches == 0) scheduleStockRefresh();
            else oiRefreshPolls = 0;
        });
    }

    private int oiRefreshPolls = 0;
    /** Re-pull this order's stock every 30s (bounded) while a background inventory
     *  sync runs, so the landing table freshens itself without the operator waiting. */
    private void scheduleStockRefresh() {
        if (oiRefreshPolls >= 5) { oiRefreshPolls = 0; return; }
        oiRefreshPolls++;
        h.postDelayed(() -> { if (!isFinishing()) viewInventory(); }, 30000);
    }

    @Override protected void onResume() { super.onResume(); applyCompletedState(); }

    /** Once every item on the order has been scanned, scanning is closed. In
     *  read-only view mode there is never a scan button. */
    private void applyCompletedState() {
        if (viewOnly) { b.btnScan.setVisibility(View.GONE); return; }
        boolean done = ScanDraftStore.isCompleted(this, so);
        if (done) {
            b.btnScan.setText("Completed");
            b.btnScan.setEnabled(false);
            b.btnScan.setVisibility(View.VISIBLE);
            b.tvStatus.setText("This order has been fully scanned and is completed.");
        } else {
            b.btnScan.setText("Start scanning this order");
            b.btnScan.setEnabled(true);
        }
    }

    private String idealFor(String code, String name) {
        ProductMaster m = ApiClient.masterOrNull();
        if (m == null) return "";
        ProductMaster.Product p = m.find(code, name);
        return (p != null && p.idealWarehouse != null) ? p.idealWarehouse.trim() : "";
    }

    private static String norm(String s) { return s == null ? "" : s.toLowerCase(Locale.ROOT).trim().replaceAll("\\s+", " "); }

    private void showProgress(String msg) {
        TextView t = new TextView(this);
        t.setPadding(48, 40, 48, 40); t.setTextSize(15); t.setText(msg);
        progressText = t;
        progress = new AlertDialog.Builder(this).setView(t).setCancelable(false).create();
        progress.show();
    }
    private void dismissProgress() { if (progress != null) { progress.dismiss(); progress = null; } }
    private void toast(String m) { android.widget.Toast.makeText(this, m, android.widget.Toast.LENGTH_LONG).show(); }
}
